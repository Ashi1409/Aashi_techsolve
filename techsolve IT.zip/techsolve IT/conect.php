<?php 

if(isset($_POST['submit']))
{
    $firstname=$_POST['$firstname'];
    $phonenumber=$_POST['$phonenumber'];
    $email=$_POST['$email'];
    $subject=$_POST['$subject'];
    $message=$_POST['$message'];


}

$server="localhost";
$username="root";
$password=" ";
$dbname="form";

$conn= new mysqli($server, $username, $password, $dbname);

if(!$conn) {
    die("failed". mysqli_connect_error());

}


    $sql="INSERT INTO conect_form(firstname, phonenumber, email, subject, message) value('$firstname','$phonenumber', 'email', 'subject','message')";
    $co=mysqli_query($coon, $sql);

    if($co){
        echo "added";

    }
    mysqli_close($conn);








?>